import numpy as np

# (a) create v = (2, 4, 6, ..., 40) and reshape into a 4x5 matrix
v = np.arange(2, 42, 2)
M = v.reshape((4, 5))
print("v =", v)
print("M =\n", M)

# (b) shape, ndim, dtype, transpose

print("\nshape: ", M.shape)
print("ndim: ", M.ndim)
print("dtype: ", M.dtype)
print("transpose: \n", M.T)

# (c) second row, last column, submatrix (rows 2-3, cols 1-3, 1-based)

print("\nsecond row:", M[1])
print("last column:", M[:, -1])
print("submatrix rows 2-3, cols 1-3:\n", M[1:3, 0:3])

# (d) row means and column standard deviations

print("\nrow means (axis =1): ", M.mean(axis=1))
print("column standard deviations (axist=0): ", M.std(axis=0))

# (e) view vs copy
B = M[:2, :2]
B[0, 0] = -1
print("\nM after modifying B (no .copy()):\n", M)  

M2 = v.reshape((4, 5))          
B2 = M2[:2, :2].copy()
M2[0, 0] = -99
print("\nM2 after modifying B2 (with .copy()):\n", M2)

