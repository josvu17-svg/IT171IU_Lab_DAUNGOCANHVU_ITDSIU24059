import numpy as np
from matplotlib.pyplot import subplots

rng = np.random.default_rng(2026)
x = rng.standard_normal(100)

# (a) eps ~ N(0, 0.5^2) -> std = 0.5
eps = rng.normal(0, 0.5, size=100)

# (b)  y = 2 + 3x + eps
y = 2 + 3 * x + eps
print(np.corrcoef(x, y))

# (c) Draw a scatter plot

fig, ax =subplots(figsize=(6, 4))
ax.scatter(x, y, label='data')
x_line = np.linspace(x.min(), x.max(), 100)
ax.plot(x_line, 2 + 3 * x_line, color = 'red', label = " y = 2 + 3x")
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_title("y = 2 + 3x + noise")
ax.legend()
fig.savefig("ex2_scatter.png", dpi=150)
