import pandas as pd
from pathlib import Path

data_path = Path(__file__).parent.parent / "Auto.data.csv"
Auto_raw = pd.read_csv(data_path, na_values=["?"])
print(Auto_raw.shape)

# (a) number of rows with at least one missing value, then drop them
n_missing = Auto_raw.isna().any(axis=1).sum()
print("Rows with missing values:", n_missing)

Auto_clean = Auto_raw.dropna()
print(Auto_clean.shape)

# (b) quantitative vs qualitative variables
# Quantitative: mpg, cylinders, displacement, horsepower, weight, acceleration, year
# Qualitative: origin, name
Auto_clean = Auto_clean.copy()
Auto_clean["origin"] = Auto_clean["origin"].map({1: "America", 2: "Europe", 3: "Japan"})

# (c) range, mean, std for every quantitative variable
quant_vars = ["mpg", "cylinders", "displacement", "horsepower", "weight", "acceleration", "year"]
summary = Auto_clean[quant_vars].agg(["min", "max", "mean", "std"])
summary.loc["range"] = summary.loc["max"] - summary.loc["min"]
print(summary)