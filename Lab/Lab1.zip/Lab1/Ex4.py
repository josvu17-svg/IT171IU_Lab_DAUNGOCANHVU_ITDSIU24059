import pandas as pd
import numpy as np
from pathlib import Path

data_path = Path(__file__).parent.parent / "Auto.data.csv"
Auto_raw = pd.read_csv(data_path, na_values=["?"])
print(Auto_raw.shape)


n_missing = Auto_raw.isna().any(axis=1).sum()
Auto_clean = Auto_raw.dropna()
Auto_clean = Auto_clean.copy()
Auto_clean["origin"] = Auto_clean["origin"].map({1: "America", 2: "Europe", 3: "Japan"})
quant_vars = ["mpg", "cylinders", "displacement", "horsepower", "weight", "acceleration", "year"]
summary = Auto_clean[quant_vars].agg(["min", "max", "mean", "std"])
summary.loc["range"] = summary.loc["max"] - summary.loc["min"]
print(summary)

keep = np.r_[0:9, 85:len(Auto_clean)]
Auto_sub = Auto_clean.iloc[keep]
summary_sub = Auto_sub[quant_vars].agg(["min", "max", "mean", "std"])
summary_sub.loc["range"] = summary_sub.loc["max"] - summary_sub.loc["min"]
print(summary_sub)

print("\nDifference (before - after):")
print(summary - summary_sub)