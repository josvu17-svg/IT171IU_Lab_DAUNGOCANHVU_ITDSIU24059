import pandas as pd
from pathlib import Path
from matplotlib.pyplot import subplots

data_path = Path(__file__).parent.parent / "Auto.data.csv"
Auto_raw = pd.read_csv(data_path, na_values=["?"])
Auto_clean = Auto_raw.dropna().copy()
Auto_clean["origin"] = Auto_clean["origin"].map({1: "America", 2: "Europe", 3: "Japan"})

# (a) scatter-plot matrix
cols = ["mpg", "displacement", "horsepower", "weight", "acceleration"]
pd.plotting.scatter_matrix(Auto_clean[cols], figsize=(9, 9))

# (b) side-by-side box plots: mpg by origin, mpg by cylinders
fig, axes = subplots(1, 2, figsize=(12, 4))
Auto_clean.boxplot(column="mpg", by="origin", ax=axes[0])
Auto_clean.boxplot(column="mpg", by="cylinders", ax=axes[1])
fig.tight_layout()
fig.savefig("ex5_boxplots.png", dpi=150)