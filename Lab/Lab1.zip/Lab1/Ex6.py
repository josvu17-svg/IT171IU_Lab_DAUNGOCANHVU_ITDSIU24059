from ISLP import load_data
import pandas as pd 
from matplotlib.pyplot import subplots

College = load_data("College")
print(College.shape)

# (a) first 5 rows and describe()

print(College.head())
print(College.describe())

# (b) how many colleges are private

n_private = (College["Private"] == "Yes").sum()
print("Number of private college: ", n_private)

# (c) create Elite variable

College['Elite'] = pd.cut(College["Top10perc"], [0,50,100], labels = ["No", "Yes"])
n_elite = (College["Elite"] == "Yes").sum()
print("Number of elite colleges: ", n_elite)
print(College["Elite"].value_counts())

 # (d) box plots: Outstate vs Private, Outstate vs Elite 

fig, axes = subplots(1, 2, figsize =(12,4))
College.boxplot(column ="Outstate", by="Private", ax=axes[0])
College.boxplot(column="Outstate", by="Elite", ax=axes[1])
fig.suptitle("")
fig.tight_layout()
fig.savefig("ex6_boxplots.png", dpi = 150)

# (e) 2x2 grid of histograms with different bin counts 

fig2, axes2 = subplots(2, 2, figsize = (10, 8))
College["Outstate"].hist(ax=axes2[0, 0], bins= 10)
axes2[0 ,0].set_title("Outstate (bins = 10)")

College["Apps"].hist(ax=axes2[0, 1], bins=20)
axes2[0, 1].set_title("Apps (bins =20)")

College["Grad.Rate"].hist(ax=axes2[1,0], bins=15)
axes2[1,0].set_title("Grad.Rate (bins = 15)")

College["Room.Board"].hist(ax=axes2[1, 1], bins =30)
axes2[1,1].set_title("Room.Board (bins = 30)")

fig2.tight_layout()
fig2.savefig("ex6_histogram.png", dpi = 150)