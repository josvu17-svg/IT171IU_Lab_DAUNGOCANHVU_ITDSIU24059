import pandas as pd
from pathlib import Path

# Redo Ex3 cleaning first, since Ex7 needs Auto_clean 

data_path = Path(__file__).parent.parent / "Auto.data.csv"
Auto_raw = pd.read_csv(data_path, na_values = ["?"])
Auto_clean = Auto_raw.dropna().copy()

quantitative = ["mpg", "cylinders", "displacement", "horsepower", "weight", "acceleration", "year"]

for col in quantitative: 
    mean = Auto_clean[col].mean()
    sd = Auto_clean[col].std()
    share = (Auto_clean[col] > mean).mean()
    print(f"{col:<12} mean = {mean:6.2f} sd = {sd:6.2f} above-mean share = {share:1%}")