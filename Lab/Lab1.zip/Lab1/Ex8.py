import numpy as np

f = lambda x: np.sin( 2 * x )+ 0.5 * x
sigma = 0.4
n_train = 60
x0, n_rep = 1.0, 200
f_x0 = f(x0)

rng = np.random.default_rng(171)

results ={}
for d in [1, 3, 5, 10, 15]:
    preds = []
    for r in range(n_rep):
        x_tr = rng.uniform(-3 , 3, n_train)
        y_tr = f(x_tr) + rng.normal(0, sigma, n_train)
        coef = np.polyfit(x_tr, y_tr, deg=d)
        preds.append(np.polyval(coef, x0))
    preds = np.array(preds)
    bias2 = (preds.mean()- f_x0 ** 2)
    variance = preds.var()
    results[d] = (bias2, variance)
print(results)

from matplotlib.pyplot import subplots

degrees = list(results.keys())
bias2_vals =[results[d][0] for d in degrees]
var_vals = [results[d][1] for d in degrees]

fig, ax = subplots(figsize = ( 7, 4.5))
ax.plot(degrees, bias2_vals, 'o-', label=r'Bias$^2$')
ax.plot(degrees, var_vals, 's-', label = 'Variance')
ax.plot(degrees, np.array(bias2_vals) + np.array(var_vals), '^--', label= r'Bias$^2$ + Variance')
ax.set_xlabel('polynomial degree (d)')
ax.set_ylabel('value')
ax.legend()
fig.savefig("ex8_bias_variance.png", dpi =150)