import numpy as np
from matplotlib.pyplot import subplots


rng = np.random.default_rng(2)
n = 200
X_tr = np.vstack([rng.normal([0, 0], 1, (n, 2)), rng.normal([1.5, 1.5], 1, (n, 2))])
y_tr = np.repeat([0, 1], n)
X_te = np.vstack([rng.normal([0, 0], 1, (500, 2)), rng.normal([1.5, 1.5], 1, (500, 2))])
y_te = np.repeat([0, 1], 500)

def knn_predict(X_train, y_train, X_new, K):
    d2 = ((X_new[:, None, :] - X_train[None, :, :])**2).sum(axis=2)
    nearest = np.argsort(d2, axis=1)[:, :K]
    return (y_train[nearest].mean(axis=1) > 0.5).astype(int)

K_values = range(1, 101)
train_err, test_err = [], []

for K in K_values:
    pred_tr = knn_predict(X_tr, y_tr, X_tr, K)
    pred_te = knn_predict(X_tr, y_tr, X_te, K)
    train_err.append(np.mean(pred_tr != y_tr))
    test_err.append(np.mean(pred_te != y_te))

inv_K = 1 / np.array(list(K_values))

fig,ax = subplots(figsize=(7, 4.5))
ax.plot(inv_K, train_err, 'o-', label='training error', markersize=3)
ax.plot(inv_K, test_err , 's-', label='test error', markersize= 3)
ax.set_xscale('log')
ax.set_xlabel('1/K (log scale)')
ax.set_ylabel('error rate')
ax.legend()
fig.savefig("ex9_knn_errors.png", dpi = 150)

best_K = list(K_values)[int(np.argmin(test_err))]
print("K minimizing test error: ", best_K, " test error = ", min(test_err))